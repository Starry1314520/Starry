from ultralytics import YOLO

if __name__ == '__main__':
    model = YOLO("yolo11s.pt")
    model.train(data=r"D:\yolov11\mydata.yaml",
                epochs=600,
                batch=8,
                workers=0,
                imgsz=640)
