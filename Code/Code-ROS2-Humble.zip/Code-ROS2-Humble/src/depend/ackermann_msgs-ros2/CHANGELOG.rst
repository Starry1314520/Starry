Change history
==============

2.0.2 (2019-08-28)
------------------
* missing std msg dependency
* Contributors: Rousseau Vincent

2.0.1 (2019-08-14)
------------------
* Initial version for ros2
* Contributors: Marcel Stüttgen

