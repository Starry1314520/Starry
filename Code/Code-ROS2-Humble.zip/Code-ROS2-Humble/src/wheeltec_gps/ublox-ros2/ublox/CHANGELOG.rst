^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ublox
^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.3.0 (2022-04-13)
------------------

2.0.0 (2020-10-13)
------------------
* Initial ROS 2 port to Dashing
* Port the ublox package to ROS 2.
* Start ROS 2 port by COLCON_IGNORE everything.
* Contributors: Chao Qu, Chris Lalancette

1.2.0 (2019-11-19)
------------------

1.1.2 (2017-08-02)
------------------
* README and package xml updates
* Contributors: Veronica Lane

1.1.0 (2017-07-17)
------------------
* Updated package xmls with new version number and corrected my email address. Also updated readme to include information about new version plus new parameter
* README and ublox package version
* Contributors: Veronica Lane

1.0.0 (2017-06-23)
------------------
* added myself as maintainer to package xmls and updated version numbers of modified packages.
* Contributors: Veronica Lane

0.0.5 (2016-08-06)
------------------

0.0.4 (2014-12-08)
------------------

0.0.3 (2014-10-18)
------------------
* Updated readme to reflect changes
* Contributors: Gareth Cross

0.0.2 (2014-10-03)
------------------

0.0.1 (2014-08-15)
------------------

0.0.0 (2014-06-23)
------------------
* ublox: first commit
* Contributors: Chao Qu
