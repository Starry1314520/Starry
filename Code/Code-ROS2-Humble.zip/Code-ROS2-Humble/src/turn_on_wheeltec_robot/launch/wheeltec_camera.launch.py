import os
from pathlib import Path
import launch_ros.actions
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (DeclareLaunchArgument, GroupAction,
                            IncludeLaunchDescription, SetEnvironmentVariable)
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_xml.launch_description_sources import XMLLaunchDescriptionSource

def generate_launch_description():
	astra_dir = get_package_share_directory('astra_camera')
	astra_launch_dir = os.path.join(astra_dir,'launch')
 
	usbcam_dir=get_package_share_directory('usb_cam')
	usbcam_launch_dir = os.path.join(usbcam_dir,'launch')

	usbcam_arg = DeclareLaunchArgument(
		'video_device', default_value='/dev/video0',
		description='video device serial number.')
 
	Astra_S = IncludeLaunchDescription(
	XMLLaunchDescriptionSource(os.path.join(astra_launch_dir,"astra_mini.launch.py",))
    )
    
	wheeltec_camera = IncludeLaunchDescription(
	PythonLaunchDescriptionSource(os.path.join(astra_launch_dir,'astra_mini.launch.py')),)
    

	# Create the launch description and populate
	ld = LaunchDescription()
	
	#Select your camera here, options include:
	#Astra_S、Astra_Pro、Dabai、Gemini、Wheeltec_Usbcam
	ld.add_action(wheeltec_camera)

	ld.add_action(usbcam_arg)

	return ld
