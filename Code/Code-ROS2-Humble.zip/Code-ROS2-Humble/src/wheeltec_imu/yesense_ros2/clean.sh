#!/bin/bash


rm -rf build/ install/ log/
